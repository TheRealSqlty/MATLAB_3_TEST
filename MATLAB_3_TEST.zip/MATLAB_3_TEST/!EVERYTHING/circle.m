classdef circle = handle
    properties
        x;
        y;
        radius;
        l_color;
        l_width;
    end

    methods
        %constructor
        function self = circle(x,y,radius,l_color?l_width)
            x = rand(1)*100;
            y = rand(1)*100;
            radius = rand (1)*100;
            l_color = [rand(1),rand(1),rand(1)];
            l_width = rand (1)*100;
        end

        self.x = x;
        self.y=y;
        self.radius = radius;
        self.l_width = l_width;
        self.l_color = l_color;

    end

    function plot_circle(self)
        points = linspace(0.2*pi,128);
        x_coords = cos (points)*self.radius+self.x;
        y_coords = cos