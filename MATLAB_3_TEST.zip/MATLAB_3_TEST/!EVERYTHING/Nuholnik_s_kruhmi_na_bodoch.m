% 1. Setup Environment
close all;  % Close all figures
clc;        % Clear the Command Window
clear;      % Clear the Workspace

% 2. Define Parameters
N = 10;     % Number of sides for the N-gon (from example)
R = 1;      % Radius of the N-gon's circumscribed circle
n = 10;     % Number of points for the small circles (from example)
r = 0.1;    % Radius of the small circles

% 3. Call Function to Prepare Data
% This local function (defined at the end) gets the N-gon vertices
% and all the points for the small circles.
[Ngon_vertices, small_circles_data] = preparePlotData(N, R, n, r);

% 4. Plot the results
figure;     % Create a new figure window
hold on;    % Hold the plot to draw multiple things

% --- Plot the N-gon ---
% We get the x-coords (row 1) and y-coords (row 2)
% We add the first point to the end to close the polygon
plot([Ngon_vertices(1, :), Ngon_vertices(1, 1)], ...
     [Ngon_vertices(2, :), Ngon_vertices(2, 1)], ...
     'b-', 'LineWidth', 1.5); % Blue line

% --- Plot the small circles ---
% Loop through each of the 'N' circles
for i = 1:N
    % Get the data for the i-th circle
    current_circle_points = small_circles_data{i};
    
    % Plot the x (row 1) and y (row 2) points as red stars
    plot(current_circle_points(1, :), ...
         current_circle_points(2, :), ...
         'r*', 'MarkerSize', 8);
end

hold off;   % Release the plot

% 5. Format the Plot
axis equal; % Ensures circles look circular, not oval
grid on;    % Add a grid
title(['N-gon (N=', num2str(N), ') with Circles (n=', num2str(n), ')']);
xlabel('X');
ylabel('Y');

fprintf('Plot complete.\n');


% -------------------------------------------------------------------
%  FUNCTION DEFINITION
% -------------------------------------------------------------------
% In MATLAB scripts, local functions must be defined at the end.
%
function [Ngon_vertices, circle_points] = preparePlotData(N, R, n, r)
    % This function calculates the N-gon vertices and the points
    % for the small circles at each vertex.

    % --- Part A: Calculate N-gon vertices ---
    
    % Create N evenly spaced angles from 0 to 2*pi
    % We use (N+1) and then drop the last point to avoid 0 and 2*pi
    % being the same point.
    t_Ngon = linspace(0, 2*pi, N + 1);
    t_Ngon = t_Ngon(1:N); % Keep only the first N points
    
    % Calculate the (x, y) coordinates for the N vertices
    Ngon_x = R * cos(t_Ngon);
    Ngon_y = R * sin(t_Ngon);
    
    % Store in a 2xN matrix: [x1, x2, ...; y1, y2, ...]
    Ngon_vertices = [Ngon_x; Ngon_y];
    
    % --- Part B: Calculate points for small circles ---
    
    % Create 'n' angles for the small circles
    t_circle = linspace(0, 2*pi, n + 1);
    t_circle = t_circle(1:n); % Keep n points
    
    % Create the base circle points (x and y) centered at (0,0)
    base_circle_x = r * cos(t_circle);
    base_circle_y = r * sin(t_circle);
    
    % 'circle_points' will be a cell array,
    % where each cell holds the data for one small circle.
    circle_points = cell(1, N);
    
    % Loop through each vertex of the N-gon
    for i = 1:N
        % Get the center of the i-th small circle
        center_x = Ngon_vertices(1, i); % x-coord of the vertex
        center_y = Ngon_vertices(2, i); % y-coord of the vertex
        
        % Add the center's (x,y) offset to the base circle points
        % This "moves" the small circle to the correct vertex
        final_circle_x = base_circle_x + center_x;
        final_circle_y = base_circle_y + center_y;
        
        % Store this circle's points in the cell array
        circle_points{i} = [final_circle_x; final_circle_y];
    end
end