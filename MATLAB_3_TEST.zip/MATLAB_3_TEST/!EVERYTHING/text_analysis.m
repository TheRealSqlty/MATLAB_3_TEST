function [n_characters,n_words,n_sentences] = text_analysis(text)



arguments (Input)
    text
end

arguments (Output)
    n_characters
    n_words
    n_sentences
    
end

n_characters = length(text);

words = split(text); 
    words = words(~cellfun('isempty', words));
    
    n_words = length(words);

n_bodky = count(text,'.');
n_otazniky = count(text,'?');
n_vykricniky = count(text,'!');

n_sentences = n_bodky+n_otazniky+n_vykricniky;


end