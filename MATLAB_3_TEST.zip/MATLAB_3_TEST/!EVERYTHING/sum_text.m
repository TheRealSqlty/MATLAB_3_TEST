function output = sum_text(text)
% SUM_TEXT Calculates the result of a simple math series from a text string.
%   The string must be in the format 'OP1 Num1 OP2 Num2 =', where OP1 and
%   OP2 are '+' or '-'.
%
%   Examples:
%       sum_text('+20+40=') returns 60
%       sum_text('-20+40=') returns 20
%       sum_text('-20-40=') returns -60 (based on logic, though example output suggests '[]')
%       sum_text('+200-40=') returns 160
%       sum_text('-20+40') returns []

    % Check for the required '=' sign
    if ~contains(text, '=')
        output = []; % Return empty vector if '=' is missing
        return;
    end

    % Remove the '=' sign for easier parsing
    text_processed = strrep(text, '=', '');

    % Find the indices of the '+' and '-' signs
    plus_indices = strfind(text_processed, '+');
    minus_indices = strfind(text_processed, '-');
    op_indices = sort([plus_indices, minus_indices]);

    % A valid math problem must have at least two operators
    if length(op_indices) < 2
        % This condition handles cases like '+20=' which don't fit the
        % "four possibilities" rule: (++, +-, -+, --)
        output = [];
        return;
    end

    % The first number starts after the first operator
    op1_index = op_indices(1);
    op2_index = op_indices(2);

    % Extract the operator signs
    op1 = text_processed(op1_index);
    op2 = text_processed(op2_index);

    % Extract the numbers as strings
    num1_str = text_processed(op1_index + 1 : op2_index - 1);
    num2_str = text_processed(op2_index + 1 : end);

    % Convert the number strings to actual numbers
    % We are told 'str2num' is banned, so we use 'str2double'
    num1 = str2double(num1_str);
    num2 = str2double(num2_str);

    % Handle cases where string conversion fails (e.g., if there's no number between ops)
    if isnan(num1) || isnan(num2)
        output = [];
        return;
    end

    % Initialize the result with the first number and its sign
    if op1 == '+'
        result = num1;
    else % op1 == '-'
        result = -num1;
    end

    % Apply the second operation
    if op2 == '+'
        result = result + num2;
    else % op2 == '-'
        result = result - num2;
    end

    % The task's examples suggest that an output must be '[]' if the math
    % problem is *not* one of the four specified possibilities (++,-+,+-,--)
    % However, the example `-20+40=` outputs `20`, and `+200-40=` outputs `160`.
    % The example `-20-40=` has an output of `[]`.
    % Let's implement the logic based on the math, and add a check for the specific
    % case `-20-40=` if required, but the instruction implies a calculation
    % for all four types. Since the core task is to calculate the sum, we
    % return the calculated result.

    % Return the final result
    output = result;

    % NOTE on the `-20-40=` example:
    % The math for '-20-40=' is $-20 - 40 = -60$. The provided example output
    % of '[]' seems to contradict the rule "So only four possibilities of math
    % problem (++,-+,+-,--)". If you *must* return `[]` for this specific
    % case, you would add:
    % if strcmp(op1, '-') && strcmp(op2, '-')
    %     output = [];
    % end
    % However, the general implementation above will return -60, which is mathematically correct
    % for the input. I will provide the mathematically correct result here.
    % If your instructor insists on `[]` for `--`, you'll need the if-statement.
end