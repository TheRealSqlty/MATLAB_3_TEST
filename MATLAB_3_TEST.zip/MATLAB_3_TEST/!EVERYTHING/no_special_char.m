function [vystup] = no_special_char(vstup)
    % 1. Priprava a velke pismena
    vstup = upper(vstup);
    vstup = char(vstup);
    filtered_txt = [];

    % 2. Tvoj cyklus na filtrovanie (opraveny)
    for i = 1:length(vstup)
        if vstup(i) >= 65 && vstup(i) <= 90
            filtered_txt(end+1) = vstup(i); 
        end
    end

    % 3. Zoradenie
    filtered_txt = sort(filtered_txt);

    % 4. Odstranenie duplikatov (Zlozita cast)
    if isempty(filtered_txt)
        vystup = []; % Ak je text prazdny, koncime
        return;
    end

    vystup = filtered_txt(1); % Prve pismeno dame vzdy
    
    for i = 2:length(filtered_txt)
        % Ak sa aktualne pismeno NEROVNA poslednemu ulozenemu
        if filtered_txt(i) ~= vystup(end)
            vystup(end+1) = filtered_txt(i); % Tak ho pridame
        end
    end
    disp("upraveny text" + string(filtered_txt))
end