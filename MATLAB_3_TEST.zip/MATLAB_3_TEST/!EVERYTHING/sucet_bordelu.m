clc,clear,close all;

bordel = '12 2_3-5, 5 und 7';
novybordel = [];
odstranene_znaky = 0;
sucet = 0;
aktualne_cislo = [];


for i = 1:length(bordel)
    if bordel(i) >= 48 && bordel(i) <=57
    aktualne_cislo=[aktualne_cislo bordel(i)];
    else
        odstranene_znaky = odstranene_znaky+1;
        if ~isempty(aktualne_cislo)
     ciselna_hodnota = str2double(aktualne_cislo);
     sucet = sucet + ciselna_hodnota;
     aktualne_cislo = [];
        end
    end

end
if ~isempty(aktualne_cislo)
     sucet = sucet + ciselna_hodnota;
end

disp(sucet)
disp("odstranene znaky : " + string(odstranene_znaky))