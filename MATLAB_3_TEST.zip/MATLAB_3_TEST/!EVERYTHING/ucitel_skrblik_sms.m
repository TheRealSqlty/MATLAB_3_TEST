text = 'ahoj, zkouska test'
mezery = find(text==' ');
text2 = text;
text2(mezery+1) = text2(mezery+1)+'Z'-'z'
text2(mezery) = []