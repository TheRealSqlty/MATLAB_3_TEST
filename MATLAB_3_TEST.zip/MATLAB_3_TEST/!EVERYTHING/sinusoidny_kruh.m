clc,clear,close all;


R=5;
N=5;
theta=linspace(0,2*pi,1000);

D=R/2;

x=R*cos(theta);
y=R*sin(theta);
z=sin(theta*N);


figure;
hold on;

pos=z>=0;
neg=z<0;
plot3(x(pos),y(pos),z(pos),'r*')
plot3(x(neg),y(neg),z(neg),'k*')
hold off;
axis equal;