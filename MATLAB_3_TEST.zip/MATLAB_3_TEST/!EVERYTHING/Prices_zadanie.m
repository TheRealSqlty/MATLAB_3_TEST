%% 1. Preparation: Clean up the environment
close all;      % Close all figure windows
clc;            % Clear the command window
clear;          % Clear all variables from the workspace

%% 2. Load data from the file
% The file contains " CZK" after each price, so we use textscan for robust parsing.
fileID = fopen('prices.txt', 'r');
% Read each line: '%f' for the number, '%s' for the ' CZK' text
data = textscan(fileID, '%f %s', 'Delimiter', '\n'); 
fclose(fileID);

% Extract only the numerical values (the prices)
daily_prices = data{1};
total_days = length(daily_prices); % Should be 100 based on the task description
days = 1:total_days; 

%% 3. Identify Highs and Lows in 10-day Intervals
interval_days = 10;
num_blocks = floor(total_days / interval_days); % Number of 10-day blocks (100/10 = 10)

% Pre-allocate marker arrays with NaN. NaN values are ignored by the plot function.
max_markers = NaN(size(daily_prices));
min_markers = NaN(size(daily_prices));

for k = 0:num_blocks-1
    % Define the indices for the current 10-day block (e.g., 1-10, 11-20, ...)
    start_index = k * interval_days + 1;
    end_index = (k + 1) * interval_days;
    
    % Ensure we don't exceed the data bounds (only relevant if total_days is not a multiple of 10)
    end_index = min(end_index, total_days);
    
    % Extract the prices for the current block
    block_prices = daily_prices(start_index:end_index);
    
    % Find the maximum and minimum values and their positions within the block
    [max_val, max_pos_in_block] = max(block_prices);
    [min_val, min_pos_in_block] = min(block_prices);
    
    % Calculate the absolute index in the full daily_prices array
    max_index = start_index + max_pos_in_block - 1;
    min_index = start_index + min_pos_in_block - 1;
    
    % Store the price value at the corresponding position in the marker arrays
    % This is the value that will be plotted as a marker.
    max_markers(max_index) = max_val;
    min_markers(min_index) = min_val;
end

%% 4. Plot the data
figure;  % Create a new figure
hold on; % Allow multiple plots on the same axes

% Plot the daily stock values (blue line)
plot(days, daily_prices, 'b-', 'LineWidth', 1);

% Plot the highest values (Green circular markers)
plot(days, max_markers, 'go', 'MarkerSize', 8, 'MarkerFaceColor', 'g');

% Plot the lowest values (Red circular markers)
plot(days, min_markers, 'ro', 'MarkerSize', 8, 'MarkerFaceColor', 'r');

hold off; % Release the plot

%% 5. Add labels and formatting
xlabel('Dny');                % X-axis label ("Days")
ylabel('Ceny [CZK]');         % Y-axis label ("Prices [CZK]")
title('Hodnota akcie za posledních 100 dní'); % Title
grid on;                      % Turn on the grid
xlim([0, total_days]);        % Set x-axis limits