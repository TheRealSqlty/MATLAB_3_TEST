function [] = plot_triangle(a,b,c)

if a+b<=c || b+c<=a || a+c<=b
    disp('špatny strany')
    return;
end

strany = sort([a,b,c], 'descend');
L1 = strany(1);
L2 = strany(2);
L3 = strany(3);

gama = acos((L3^2+L2^2-L1^2)/(2*L3*L1));

x3 = L3 * cos(gama);
y3 = L3 * sin(gama);


X = [0,L1,x3,0];
Y = [0,0,y3,0];
    plot(X, Y)


end
