clc,clear;

M = Mechduino("COM5");
LED_GND = M.get_LED(2);
LED_R = M.get_LED(4);
LED_Y = M.get_LED(6);
LED_G = M.get_LED(8);

LED_GND.turn_off
LED_R.light_up
LED_Y.light_up
LED_G.light_up


%%BLIKANIE (ak chcem aby iba svietilo odstran kod dole)
for i= 1:10


    LED_R.light_up
    LED_Y.light_up
    LED_G.light_up
    M.pause(1000);

    LED_R.turn_off
    LED_Y.turn_off
    LED_G.turn_off

    M.pause(1000);
end