function Gcode_parser(gcode)
    % Gcode_parser - parses simple G0 and G1 commands and animates them
    % Input: cell array of strings with commands, e.g.:
    % {'G0 0 0', 'G0 15 15', 'G1 30 15', 'G1 30 30', 'G1 15 30', 'G1 15 15', 'G0 0 0'}

    % Setup plotting area
    figure('Color','w');
    axis([0 40 0 40]);
    axis equal;
    grid on;
    hold on;
    xlabel('X [mm]');
    ylabel('Y [mm]');
    title('Pseudo G-code plotter');

    % Start position
    pos = [0 0];
    h = plot(pos(1), pos(2), 'ko', 'MarkerFaceColor','k'); % tool head

    for i = 1:length(gcode)
        % Split command line
        parts = strsplit(strtrim(gcode{i}));
        cmd = upper(parts{1});
        x = str2double(parts{2});
        y = str2double(parts{3});
        newPos = [x y];

        % Draw based on command
        switch cmd
            case 'G0'  % Rapid move - green dotted
                plot([pos(1) newPos(1)], [pos(2) newPos(2)], 'g:','LineWidth',1.5);
            case 'G1'  % Feed move - blue solid
                plot([pos(1) newPos(1)], [pos(2) newPos(2)], 'b-','LineWidth',2);
            otherwise
                warning('Unknown command: %s', cmd);
        end

        % Animate tool motion
        steps = 20;
        for s = 1:steps
            current = pos + (newPos - pos) * s/steps;
            set(h, 'XData', current(1), 'YData', current(2));
            drawnow;
            pause(0.02);
        end

        % Update current position
        pos = newPos;
    end
end
