function [vystup] = any_vector(vektor,row,column)


vektor_size= row*column;
vektor_length = length(vektor);
vystup = zeros(row,column);



if vektor_length == vektor_size

    
    for i = 1:row
        zaciatok = (i-1)*column +1 ;
        vystup (i,:) = vektor(zaciatok : zaciatok+column-1)
    
    
    end
    
else 
    vystup = [];
    disp("nesedí ti vektor tupelo")


end

