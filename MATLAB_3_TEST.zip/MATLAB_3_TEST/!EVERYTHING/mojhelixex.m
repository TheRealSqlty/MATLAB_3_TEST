clc,clear,close all;


a=5;
b=1;
c=1;
mojhelix(a,b,c)

