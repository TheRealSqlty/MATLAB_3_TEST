clc,clear,close all;
x = -5:0.5:5;
y = -5:0.5:5;
[X, Y] = meshgrid(x,y);
Z = X.^2 + Y.^2; % Paraboloid
subplot(1,2,1);
surf(X, Y, Z)
title('Surface plot');
subplot(1,2,2);
contour(X,Y,Z);
title('Contour plot');