clc,clear, close all;

[x,y,z]=my_helix(5,10,3);
plot3(x,y,z)



function [x,y,z] =  my_helix(radius,pitch,turns)
    x=[];y=[];z=[];
    for i = 0:2*pi()/60:turns*2*pi()
        x = [x, cos(i)*radius];
        y = [y, sin(i)*radius];
        z = [z,pitch*i*(pi()/20)];
    end
end
