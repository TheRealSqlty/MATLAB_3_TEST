function [sms] = skrblikova_SMS(skr_sms)

slova = strsplit(skr_sms,'');
mod_slova = cell(size(slova));



for i = 1:length(slova)
        slovo = slova{i};

if ~isempty(slova)
    mod_slova{i} = [upper(slovo(1)), slova(2:end)];
else
    mod_slova{i}= '';
end
end
sms = strjoin(mod_slova, '');

end