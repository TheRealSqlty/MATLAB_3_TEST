% Script test_task_2.m: Calls the find_upper function.

% Preparation
clc;        % Clear the command window
clear;      % Clear all variables from the workspace

% Example 1: 'Toto je druHY zaPOctovy test'
text1 = 'Toto je druHY zaPOctovy test';
new_text1 = find_upper(text1);

disp(['Input:  ''', text1, '''']);
disp(['Output: ''', new_text1, '''']);
% Expected Output: '|T|oto je dru|H||Y| za|P||O|ctovy test'

disp('------------------------');

% Example 2: 'Mam rad Ovoce a Zeleninu'
text2 = 'Mam rad Ovoce a Zeleninu';
new_text2 = find_upper(text2);

disp(['Input:  ''', text2, '''']);
disp(['Output: ''', new_text2, '''']);
% Expected Output: '|M|am rad |O|voce a |Z|eleninu'