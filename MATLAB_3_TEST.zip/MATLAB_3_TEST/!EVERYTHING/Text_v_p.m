function [x, y] = Text_v_p(text)
    % Extract last two characters (plot type, e.g. 'R*', 'G*', 'B*')
    plotType = text(end-1:end);
    text = text(1:end-2);

    % Extract all number-letter pairs (e.g., 10Y, 5X, etc.)
    tokens = regexp(text, '(\d+)([XY])', 'tokens');

    % Initialize coordinate arrays
    x = [];
    y = [];

    % Fill x and y arrays
    for i = 1:length(tokens)
        val = str2double(tokens{i}{1});
        coord = tokens{i}{2};
        if coord == 'X'
            x(end+1) = val;
        elseif coord == 'Y'
            y(end+1) = val;
        end
    end

    % If lengths don't match, return empty
    if length(x) ~= length(y)
        x = [];
        y = [];
        return;
    end

    % Plot data if valid
    if ~isempty(x)
        color = lower(plotType(1));  % <-- use first character for color
        switch color
            case 'r'
                plot(x, y, 'ro', 'MarkerFaceColor', 'r');
            case 'g'
                plot(x, y, 'go', 'MarkerFaceColor', 'g');
            case 'b'
                plot(x, y, 'bo', 'MarkerFaceColor', 'b');
            otherwise
                plot(x, y, 'ko', 'MarkerFaceColor', 'k');
        end

        grid on;
        axis([0 max(x)+1 0 max(y)+1]);
    end
end
