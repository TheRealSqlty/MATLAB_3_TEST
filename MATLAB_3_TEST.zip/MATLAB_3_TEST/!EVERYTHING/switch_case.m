function output_text = switch_case(input_text)
% SWITCH_CASE Swaps the case of all letters in the input text.
%   Inputs:
%     input_text - A string of text.
%   Outputs:
%     output_text - The string with swapped case (lower to upper, and vice versa).

    % Convert the string to an array of characters
    char_array = char(input_text);
    
    % Find indices of lowercase letters
    is_lower = isstrprop(char_array, 'lower');
    
    % Find indices of uppercase letters
    is_upper = isstrprop(char_array, 'upper');
    
    % Convert all lowercase letters to uppercase
    char_array(is_lower) = upper(char_array(is_lower));
    
    % Convert all uppercase letters to lowercase
    char_array(is_upper) = lower(char_array(is_upper));
    
    % Convert the character array back to a string for the output
    output_text = string(char_array);
end