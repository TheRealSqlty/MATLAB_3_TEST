%% 1. Preparation: Clean up the environment
close all;      % Close all figure windows
clc;            % Clear the command window
clear;          % Clear all variables from the workspace

%% --- Data Generation (for demonstration purposes) ---
% This section creates the 'temp.txt' file because it wasn't provided.
% It simulates a yearly temperature cycle over 360 days.
days = 1:360;
% A sine wave to simulate seasons, plus some random daily noise
simulated_temps = 15 - 10 * cos(2*pi*days/360) + 2.5 * randn(1, 360);
% Save the data to the required file, with one temperature per line
writematrix(simulated_temps', 'temp.txt');
disp('Generated and saved sample data to temp.txt');

%% 2. Load data from the file
% Load the daily temperature measurements from the text file
daily_temps = readmatrix('temp.txt');

%% 3. Calculate the 30-day average temperature
interval_days = 30;
% Reshape the 360x1 vector into a 30x12 matrix, where each column
% represents one 30-day period.
temp_matrix = reshape(daily_temps, interval_days, []); % The [] lets MATLAB auto-calculate columns
% Calculate the mean of each column to get the 12 average values
monthly_avg_temps = mean(temp_matrix);

%% 4. Prepare data for the step plot of the average temperature
% To create the "step" effect, we repeat each average value 30 times.
% For example, the first average is repeated 30 times for days 1-30, etc.
avg_temps_step_plot = repelem(monthly_avg_temps, interval_days);

%% 5. Plot the data
figure;  % Create a new figure
hold on; % Allow multiple lines on the same plot

% Plot the daily temperatures (light blue line)
plot(days, daily_temps, 'Color', [0.3010 0.7450 0.9330], 'LineWidth', 1);

% Plot the 30-day average temperature (thick red line)
plot(days, avg_temps_step_plot, 'r', 'LineWidth', 2);

hold off; % Release the plot

%% 6. Add labels, legend, and formatting
xlabel('Dny');                % X-axis label ("Days")
ylabel('Teplota [°C]');       % Y-axis label ("Temperature [°C]")
title('Denní a průměrná teplota za 360 dní'); % Title
legend('Teplota', 'Průměrná teplota', 'Location', 'northeast'); % Legend
grid on;                      % Turn on the grid
xlim([0, 360]);               % Set x-axis limits to match the example