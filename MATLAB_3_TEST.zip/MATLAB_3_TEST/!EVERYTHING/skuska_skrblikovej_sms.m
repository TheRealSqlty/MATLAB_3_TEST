clc,clear,close all;

veta = 'Moje meno je tomáš a mám rád guláš';

smska = skrblikova_SMS(veta)