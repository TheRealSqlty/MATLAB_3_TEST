clc,clear,close all;


data = randi(10,4:5);
disp(data);
v1 = data;

v1(v1<4)=0;
vcol=length(v1);
vrow=vrow

if v1 ~= 0
    disp('zmenena hodnota')
else
    disp(v1)
end
