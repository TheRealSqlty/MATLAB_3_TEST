clc,clear,close all;

str = '  ahoj  ako sa  mas  '
old = '  ';
new = ' ';
new_str = strrep(str,old,new);
new_str