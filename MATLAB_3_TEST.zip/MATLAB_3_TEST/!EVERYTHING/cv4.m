clc,clear, close all;


x=0;
y=0;
t = linspace(0,10);



plot(t, 2*sin(3*t),'o-r')
hold on;
plot(t, mod(t,2),'b')
