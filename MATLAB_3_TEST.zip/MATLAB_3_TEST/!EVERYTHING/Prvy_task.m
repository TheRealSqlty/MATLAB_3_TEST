clc, clear; close all

t = 0:0.1:10,%s
y=2*sin(3*t);

t2=0:0.1:10
y2= 0:0.1:2


yt=mod(t2,2)


plot (t,y,"or-", "LineWidth", 1)
hold on
plot (t2,yt,"b-", "LineWidth", 3)

shg
