clc,clear,close all
C1 = circle (0 , 0 , 10,[ 0.2 0.8 0.6],10);
    C1.plot_circle()
    hold on;
    axis equal;

    %%
    for i = 1:100
        my_circle(i)= circle();
        my_circle(i).plot_circle()
    end

