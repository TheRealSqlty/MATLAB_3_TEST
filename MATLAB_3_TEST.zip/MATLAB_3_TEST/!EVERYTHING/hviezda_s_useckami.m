%% Task 3: N-pointed Star with M segments

% 1. Preparation: Clean up the environment
clc;        % Clear the command window
clear;      % Clear all variables from the workspace
close all;  % Close all open figure windows

% 2. Define Parameters (Example: 5-pointed star, 3 segments per ray)
n = 5;  % Number of rays (n)
m = 3;  % Number of segments per ray (m)
L_start = 5; % Starting length of the first segment (adjust for scale)

% 3. Prepare the figure
figure;    % Create a new figure window
hold on;   % Allow multiple plots on the same axes
grid on;   % Add a grid
axis equal;% Ensure the scaling is equal on both axes
box on;    % Add a box around the plot

% 4. Calculate angles for the rays
% The rays are spaced evenly around 2*pi (360 degrees)
angles = linspace(0, 2*pi, n + 1); 

% 5. Loop through each ray to plot it individually
for ray_index = 1:n
    
    % Define the starting point of the ray (center of the star)
    x_current = 0;
    y_current = 0;
    
    % The total length of the ray is the sum of the segment lengths
    total_ray_length = L_start * (1 - (1/2)^m) / (1 - 1/2); % Sum of geometric series
    
    % Define the direction (angle) of the current ray
    current_angle = angles(ray_index);
    
    % A) Plot the starting point (center) with a green marker
    plot(x_current, y_current, 'go', 'MarkerSize', 8, 'MarkerFaceColor', 'g');

    % Loop through the m segments of the current ray
    L_segment = L_start; % Reset segment length for the new ray
    for segment_index = 1:m
        
        % Calculate the end point of the segment based on its length and the ray angle
        x_next = x_current + L_segment * cos(current_angle);
        y_next = y_current + L_segment * sin(current_angle);
        
        % Segment data (two points: start and end of the segment)
        x_segment = [x_current, x_next];
        y_segment = [y_current, y_next];

        % Determine the plotting style based on the segment index
        if mod(segment_index, 2) == 1  % Odd numbered segment (1st, 3rd, 5th, ...)
            % Black dotted line (Černou tečkovanou čárou)
            line_style = 'k:';
            line_thickness = 1.5;
        else % Even numbered segment (2nd, 4th, ...)
            % Red solid line (Červenou plnou čarou)
            line_style = 'r-';
            line_thickness = 2;
        end

        % 1. Plot the segment line
        plot(x_segment, y_segment, line_style, 'LineWidth', line_thickness);
        
        % 2. Plot the segment endpoint (Green circular marker)
        % The start point was plotted at the center (or the end of the previous segment).
        % We plot the marker at the end point of the current segment.
        plot(x_next, y_next, 'go', 'MarkerSize', 8, 'MarkerFaceColor', 'g');

        % Update for the next segment:
        x_current = x_next;
        y_current = y_next;
        L_segment = L_segment / 2; % Length is half the previous one
    end
end

% 6. Finalize the plot
hold off; % Release the figure
title(['Plot of ', num2str(n), '-pointed Star with ', num2str(m), ' segments']);
xlabel('X-axis');
ylabel('Y-axis');

% Set axis limits dynamically based on the total ray length
axis_limit = total_ray_length * 1.2; % 20% padding
axis([-axis_limit axis_limit -axis_limit axis_limit]);