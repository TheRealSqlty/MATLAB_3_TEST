clc,clear,close all;

plot_triangle(10,10,10)