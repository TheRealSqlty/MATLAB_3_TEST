clc,clear,close all;

fdelitelnetridevat(279)