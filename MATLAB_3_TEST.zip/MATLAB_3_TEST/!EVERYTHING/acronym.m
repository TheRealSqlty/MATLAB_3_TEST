function output_acronym = acronym(text)
% ACRONYM Generates an acronym from a series of words separated by spaces.
%   Inputs:
%     text - A string containing multiple words.
%   Outputs:
%     output_acronym - The uppercase acronym.

    % 1. Split the input text string into individual words using spaces as delimiters.
    words = strsplit(text, ' ');
    
    % Initialize an empty string to build the acronym
    initial_letters = '';
    
    % 2. Loop through each word
    for i = 1:length(words)
        current_word = words{i};
        
        % Check if the word is not empty (handles multiple spaces)
        if ~isempty(current_word)
            % 3. Extract the first character of the word
            first_letter = current_word(1);
            
            % Append the first letter to the string of initials
            initial_letters = [initial_letters, first_letter];
        end
    end
    
    % 4. Convert all letters to uppercase to get the final acronym
    output_acronym = upper(initial_letters);
    
end