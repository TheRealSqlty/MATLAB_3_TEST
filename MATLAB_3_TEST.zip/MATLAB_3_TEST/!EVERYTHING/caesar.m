function out = caesar(char_array, k)
    % Caesar cipher function
    % Shifts lowercase letters by k positions (wraps around alphabet)
    % Spaces are not shifted
    % Example:
    % caesar('koza', 3) → 'nrcd'
    % caesar('nrcd', -3) → 'koza'

    out = char_array; % preallocate output same size
    for i = 1:length(char_array)
        ch = char_array(i);

        % Only process lowercase letters
        if ch >= 'a' && ch <= 'z'
            % Shift within 'a' to 'z'
            shifted = mod((double(ch) - double('a') + k), 26) + double('a');
            out(i) = char(shifted);
        else
            % Keep spaces or other characters unchanged
            out(i) = ch;
        end
    end
end
