function obdl_z_bodov(N,Xmin,Xmax,Ymin,Ymax)


stred_x = (Xmin+Xmax)/2;
sigma_x = (Xmax-Xmin)/6;
stred_y = (Ymin+Ymax)/2;
sigma_y = (Ymax-Ymin)/6;

hodnota_x = stred_x+sigma_x*randn(N,1)
hodnota_y = stred_y+sigma_y*randn(N,1)

minx=min(hodnota_x);
maxx=max(hodnota_x);
miny=min(hodnota_y);
maxy=max(hodnota_y);

w=maxx-minx;
h=maxy-miny;


hold on;
axis equal;
rectangle('Position',[minx,miny,w,h], 'EdgeColor','r')
plot(hodnota_x,hodnota_y,"bx")
hold off

end