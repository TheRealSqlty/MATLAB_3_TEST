function [val,area,circ] = calc_triangle2(a,b,c)

penis = (a+b+c)/2;

circ = a+b+c;
area = sqrt(penis*(penis-a)*(penis-b)*(penis-c));


val = a+b>c && b+c>a && a+c>b;


end