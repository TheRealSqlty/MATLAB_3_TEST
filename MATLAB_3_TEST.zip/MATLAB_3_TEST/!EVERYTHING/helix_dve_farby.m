% 1. Setup Environment
close all;  % Close all figures
clc;        % Clear the Command Window
clear;      % Clear the Workspace

% 2. Define Parameters
R = 1;          % Radius
H = 1;          % Pitch (z-distance for one 2*pi turn)
m = 3;          % Number of threads (parts)
numTurns = 2;   % Number of turns to show (to match the image)
numPoints = 100; % Number of points per thread

% 3. Call Function to Prepare Data
% This local function is defined at the end of this script
helixData = func_helix_dve_farby(R, H, m, numTurns, numPoints);

% 4. Plot the Helix
figure;     % Create a new figure window
hold on;    % Hold the plot to draw all 'm' parts

fprintf('Plotting %d helix threads...\n', m);

for i = 1:m
    % Get the data for the i-th thread
    data = helixData{i};
    x = data(1, :);
    y = data(2, :);
    z = data(3, :);

    % Check if the thread index 'i' is odd or even
    if mod(i, 2) == 1
        % Odd parts (1, 3, 5, ...): Blue cross (x)
        plot3(x, y, z, 'bx', 'MarkerSize', 8, 'LineWidth', 1.5);
        fprintf('  Plotting thread %d as Blue Cross\n', i);
    else
        % Even parts (2, 4, 6, ...): Red dot (.)
        plot3(x, y, z, 'r.', 'MarkerSize', 14);
        fprintf('  Plotting thread %d as Red Dot\n', i);
    end
end

hold off;   % Release the plot

% 5. Format the Plot
axis equal; % Ensures circles look circular
grid on;    % Add a grid
box on;     % Enclose the plot in a box
xlabel('X');
ylabel('Y');
zlabel('Z');
title(['Helix with ', num2str(m), ' Threads']);
view(3);