% Task 3: N-pointed Star Plot

% 1. Preparation: Clean up the environment
clc;        % Clear the command window
clear;      % Clear all variables from the workspace
close all;  % Close all open figure windows

% 2. Define Parameters (Example: 10-pointed star with ray length 2)
n = 10; % Number of rays (n)
L = 2;  % Length of each ray (L)

% 3. Prepare the figure
figure;    % Create a new figure window
hold on;   % Allow multiple plots on the same axes
grid on;   % Add a grid
axis equal;% Ensure the scaling is equal (important for shape integrity)
box on;    % Add a box around the plot

% 4. Calculate angles and coordinates for the rays
% The rays are spaced evenly around 2*pi (360 degrees)
angles = linspace(0, 2*pi, n + 1); % n+1 to make sure we have exactly n unique angles

% 5. Loop through each ray to plot it individually
for i = 1:n
    % The ray starts at (x0, y0) = (0, 0) and ends at (xL, yL)
    x0 = 0;
    y0 = 0;
    
    % Calculate the end point of the ray based on length L and the angle
    xL = L * cos(angles(i));
    yL = L * sin(angles(i));
    
    % The current ray data (two points: start and end)
    x_ray = [x0, xL];
    y_ray = [y0, yL];

    % Determine the plotting style based on the ray index (i)
    if mod(i, 2) == 1  % Odd numbered ray (1st, 3rd, 5th, ...)
        % Blue dashed line, thickness 1
        line_style = 'b--';
        line_thickness = 1;
    else % Even numbered ray (2nd, 4th, 6th, ...)
        % Black solid line, thickness 5
        line_style = 'k-';
        line_thickness = 5;
    end

    % A) Plot the ray line
    plot(x_ray, y_ray, line_style, 'LineWidth', line_thickness);

    % B) Plot the endpoints (red circular markers)
    % The start point is (0,0), the end point is (xL, yL)
    % The task specifies the endpoints are bounded by markers.
    % We plot markers at (0,0) and (xL, yL).
    plot(x_ray, y_ray, 'ro', 'MarkerSize', 6, 'MarkerFaceColor', 'r');
end

% 6. Finalize the plot
hold off; % Release the figure
title(['Plot of ', num2str(n), '-pointed Star with Ray Length ', num2str(L)]);
xlabel('X-axis');
ylabel('Y-axis');

% Set axis limits dynamically based on the ray length L
axis_limit = L * 1.1; % 10% padding
axis([-axis_limit axis_limit -axis_limit axis_limit]);