clc,clear, close all;

x = 0:pi/50:2*pi;
y = sin(x);

plot(x,y,".")

hold on

y2 = cos(x)

plot(x,y2,"g.")

x3 = [0,2*pi];
y3 = [0,0];
plot (x3,y3,'Color','y','LineStyle','-.')

axis equal

figure

t=0:0.1:10;
x4 = sin(t);
y4 = cos(t);
plot(x4,y4)
hold on
plot(x4/2,y4/2)
plot(x4,y4/2)
plot(x4/2,y4)

figure
hold on

for i=0:0.1:2
    plot(x4/i,y4/(2-i))
    xlim([-2 2])
    ylim([-2 2])
    pause(0.1)
end

axis equal


figure
hold on



