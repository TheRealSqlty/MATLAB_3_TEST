% clc,clear,close all;
% 
% 
% 
% r1 =2;
% r2 =5;
% 
% x=2;
% y=6;
% 
% q=rand(1,50)*10
% d=rand(1,50)*10
% 
% for i = 1:50
%     moje_hvezda(r1,r2,x+q(i),y*d(i))
% end

clc;
clear;
close all;
figure; % Create one figure window for all plots
hold on; 
axis equal;
grid on;

% 2. Define Function Parameters (Rays of the star)
r1 = 0.5; % Inner radius of the star
r2 = 1;   % Outer radius of the star
x_center = 0; % Keep the star centered on the x-axis

% 3. Define Repetition Parameters
num_repetitions = 50;
% Define the range for random y-axis displacement.
% Adjust these limits as needed based on the size of your stars (r2)
y_min = 0; 
y_max = 10; 

% 4. Loop and Plot
for i = 1:num_repetitions
    % Generate a random y-coordinate within the defined range
    y_random = y_min + (y_max - y_min) * rand(1); % rand(1) gives a number between 0 and 1
    
    % Call the function with the random y-coordinate
    moje_hvezda(r1, r2, x_center, y_random);
end

% 5. Finalize Plot
title('50 Randomly Placed Stars along the Y-axis');
xlabel('X-axis');
ylabel('Y-axis (Random Position)');
hold off;