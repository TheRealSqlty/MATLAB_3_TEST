close all;  
clc;         
clear;         


% 1. Load data from the file using the robust textscan method
fileID = fopen('temp.txt', 'r');
% Read each line: '%f' for the temperature, '%s' for the ' °C' text
data = textscan(fileID, '%f %s', 'Delimiter', '\n'); 
fclose(fileID);
daily_temps = data{1}; % Extract only the numbers

days = 1:360;
interval_days = 30;
temp_matrix = reshape(daily_temps, interval_days, []);
monthly_avg_temps = mean(temp_matrix);

avg_temps_step_plot = repelem(monthly_avg_temps, interval_days);

figure;
hold on;

plot(days, daily_temps, 'Color', [0.3010 0.7450 0.9330], 'LineWidth', 1);

% Plot the 30-day average temperature (thick red line)
plot(days, avg_temps_step_plot, 'r', 'LineWidth', 2);

hold off;

xlabel('Dny');                % X-axis label ("Days")
ylabel('Teplota [°C]');       % Y-axis label ("Temperature [°C]")
title('Denní a průměrná teplota za 360 dní'); % Title
legend('Teplota', 'Průměrná teplota', 'Location', 'northeast'); % Legend
grid on;                      % Turn on the grid
xlim([0, 360]);               % Set x-axis limits to match the example