function [] = moje_hvezda(r1,r2,x,y)
%UNTITLED4 Summary of this function goes here
%   Detailed explanation goes here
theta = linspace(0,2*pi,10);
t = theta(2)/2

x2 = r2*cos(theta);
y2 = r2*sin(theta);
x1 = r1*cos(theta-t);
y1 = r1*sin(theta-t);
x3 = r1*cos(theta+t);
y3 = r1*sin(theta+t);

for i = 1:length(theta)
    a=[x1(i),y1(i)];
    b=[x2(i),y2(i)];
    c=[x3(i),y3(i)];
    plot([a(1),b(1)],[a(2),b(2)]+y,'r')
    plot([c(1),b(1)],[c(2),b(2)]+y,'r')
        hold on
        axis equal
end
