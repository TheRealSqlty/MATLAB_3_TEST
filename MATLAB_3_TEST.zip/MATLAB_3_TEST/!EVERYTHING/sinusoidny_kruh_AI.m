% 1. Preparation: Clean up the environment
clc;        % Clear the command window
clear;      % Clear all variables from the workspace
close all;  % Close all open figure windows

% 2. Define Parameters for the plot
D = 10; % Diameter of the circle in the XY plane
N = 10; % Number of sine wave periods along the Z-axis

% 3. Generate the data points
R = D / 2; % Calculate the radius from the diameter
theta = linspace(0, 2 * pi, 1000); % Create 1000 points for a smooth circle

% Calculate the coordinates
x = R * cos(theta);                % X coordinates for the circle
y = R * sin(theta);                % Y coordinates for the circle
z = sin(N * theta);                % Z coordinates with N sine periods

% 4. Plot the data conditionally
figure;    % Create a new figure window
hold on;   % Allow multiple plots on the same axes

% Find indices for positive (and zero) and negative Z values
positive_indices = z >= 0;
negative_indices = z < 0;

% Plot positive Z values as black points
plot3(x(positive_indices), y(positive_indices), z(positive_indices), 'k.', 'MarkerSize', 10);

% Plot negative Z values as red points
plot3(x(negative_indices), y(negative_indices), z(negative_indices), 'r.', 'MarkerSize', 10);

% 5. Finalize the plot
hold off;          % Release the figure
grid on;           % Add a grid for better readability
axis equal;        % Ensure the circle looks like a circle
xlabel('X-axis');  % Label the x-axis
ylabel('Y-axis');  % Label the y-axis
zlabel('Z-axis');  % Label the z-axis
title('3D Sinusoidal Circle'); % Add a title