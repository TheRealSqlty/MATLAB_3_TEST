clc,clear, close all;

[val,area,circ] = calc_triangle2(10,5,7)