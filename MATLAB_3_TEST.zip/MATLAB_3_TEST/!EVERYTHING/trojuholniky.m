clc,clear

function calc_triangle = [2,3,5]
