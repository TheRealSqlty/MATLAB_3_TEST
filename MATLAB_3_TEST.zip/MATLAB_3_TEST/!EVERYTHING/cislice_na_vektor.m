clc,clear,close all;
my_num = '54865233';
result = [];


for i = 1:length(my_num)
    if my_num(i)>='0' && my_num(i)<='9'
        hodnota = my_num(i) - 48;
        result(end+1)=hodnota;
    else
        result = [];
        break
    end
end
result