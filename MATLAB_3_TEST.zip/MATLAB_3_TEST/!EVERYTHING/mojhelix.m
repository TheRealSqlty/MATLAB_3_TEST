function [] = mojhelix(rad,pit,num)

t = 0:pi/50:num*2*pi;
st = rad*sin(t);
ct = rad*cos(t);
plot3(st,ct,t/(2*pi),'diamond','Color',[191 128 153] / 255)



end