%% Work with data 2: Weather Data Analysis

% 1. Preparation
clc;        % Clear the command window
clear;      % Clear all variables from the workspace
close all;  % Close all open figure windows

% 2. Parameters
chosen_city = 'Miami'; % Choose a city (e.g., Miami, San Diego, Atlanta)
% Note: The file contains city names like 'Miami' and 'San Diego'.
fahrenheit_to_celsius_factor = 5/9;
fahrenheit_offset = 32;

% 3. Load Data
% Load the data from the CSV file into a table.
T = readtable('weather.csv', 'Delimiter', ',');

% Convert the Date column to a datetime format for plotting
T.Date = datetime(T.Date, 'InputFormat', 'dd-MMM-yyyy');

% 4. Filter and Process Data for the Chosen City
% Select all rows where the City column matches the chosen city
city_data = T(strcmp(T.City, chosen_city), :);

% Extract Temperature and convert from Fahrenheit (°F) to Celsius (°C)
% °C = (°F - 32) * 5/9
temperature_F = city_data.Temperature;
temperature_C = (temperature_F - fahrenheit_offset) * fahrenheit_to_celsius_factor;

% Extract Wind Speed and convert from knots to m/s
% 1 knot ≈ 0.5144 m/s (using 0.5 for simplification/common practice)
wind_knots = city_data.WindSpeed;
wind_ms = wind_knots * 0.5144; 

% Add the calculated temperature back to the city_data table for easier use
city_data.Temperature_C = temperature_C;
city_data.WindSpeed_ms = wind_ms;

% 5. Calculate Average Temperature (for plotting comparison)
avg_temp_C = mean(temperature_C);
disp(['Average temperature in ', chosen_city, ' (2016-2017): ', num2str(avg_temp_C), ' °C']);

% 6. Plot Temperature
figure;
hold on;
grid on;

% Plot 1: Daily Temperature (Red plus markers '+' with size 12)
% Check if the temperature is greater or less than the average to set color
is_above_avg = temperature_C > avg_temp_C;

% Plot above average (Red plus)
plot(city_data.Date(is_above_avg), temperature_C(is_above_avg), ...
    'r+', 'MarkerSize', 12, 'DisplayName', '> Avg Temp');

% Plot below or equal to average (Blue star)
plot(city_data.Date(~is_above_avg), temperature_C(~is_above_avg), ...
    'b*', 'MarkerSize', 8, 'DisplayName', '<= Avg Temp');

% Plot 2: Average Temperature (Line)
plot([city_data.Date(1), city_data.Date(end)], [avg_temp_C, avg_temp_C], ...
    'k--', 'LineWidth', 1.5, 'DisplayName', 'Average Temperature');

% min
[val0,idx0] = min(Y) ;
% max
[val1,idx1] = max(Y) ; 
plot(X,Y)
hold on
plot(X(idx0),Y(idx0),'*r')
plot(X(idx1),Y(idx1),'*b')

% 7. Add Labels and Formatting
xlabel('Date');
ylabel('Temperature [°C]');
title(['Temperature in ', chosen_city, ' (2016-2017)']);
legend('Location', 'best');
datetick('x', 'mmm-yy'); % Format x-axis ticks to show month and year
hold off;

%% 8. Plot Wind Speed (Optional, based on task image "Work with data 1" which asks for it)
% Note: The main task image "Work with data 2" focuses on temperature.
% If you need the wind plot from "Work with data 1" (Wind in Atlanta):
%{
figure;
plot(city_data.Date, city_data.WindSpeed_ms, 'b-', 'LineWidth', 1);
hold on;
% Find max wind speed and date
[max_wind, idx] = max(city_data.WindSpeed_ms);
plot(city_data.Date(idx), max_wind, 'ro', 'MarkerSize', 8, 'MarkerFaceColor', 'r', ...
     'DisplayName', ['Max Wind: ', num2str(max_wind, '%.2f'), ' m/s']);
hold off;

xlabel('Date');
ylabel('Wind Speed [m/s]');
title(['Wind in ', chosen_city, ' (2016-2017)']);
legend('Location', 'best');
datetick('x', 'mmm-yy'); 
grid on;
%}