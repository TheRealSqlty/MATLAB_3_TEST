function [vystup] = test_mocniny(cislo)
    while true
        nove_cislo = cislo / 2;
        
        % Ak vysledok nie je cele cislo, koncime (nie je to mocnina)
        if nove_cislo ~= floor(nove_cislo)
            vystup = [];
            disp("zlé číslo (nie je mocnina 2)")
            break; % Musime vyskocit z cyklu!
        end
        
        % Ak sme tu, cislo bolo cele. Ulozime si ho pre dalsie kolo.
        cislo = nove_cislo; 
        
        % Ak sme sa dostali az na 1, je to mocnina
        if cislo == 1
            vystup = 1; % Alebo true, alebo povodne cislo
            disp("vybrane cislo je mocninou 2")
            break; % Musime vyskocit z cyklu!
        end
    end
end