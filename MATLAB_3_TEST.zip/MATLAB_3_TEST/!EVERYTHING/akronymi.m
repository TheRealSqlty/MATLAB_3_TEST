% Script test_task_2.m: Calls the acronym function.

% Preparation
clc;        % Clear the command window
clear;      % Clear all variables from the workspace

% Example 1: 'Toto je druhy zapoctovy test'
text1 = 'Toto je druhy zapoctovy test';
new_text1 = acronym(text1);
disp(['Input:  ''', text1, '''']);
disp(['Output: ''', new_text1, '''']);
% Expected Output: 'TJDZT'

disp('------------------------');

% Example 2: 'styri penisy rovno do papule%'
text2 = 'styri penisy rovno do papule';
new_text2 = acronym(text2);
disp(['Input:  ''', text2, '''']);
disp(['Output: ''', new_text2, '''']);
% Expected Output: 'MROAZ'