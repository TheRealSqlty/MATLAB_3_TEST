function [vystup] = parne_neparne_cifry (vstup)

vstupstr = num2str(vstup)
sude = 0;
liche = 0;


for i = 1:length(vstupstr)
    aktualna_cifra = str2double(vstupstr(i));

    if mod(aktualna_cifra,2) == 1
liche = liche+1;

    else
    sude = sude+1;

    end
end
if sude > liche
    vystup ="Je viacej sudých čísiel"
elseif sude < liche
    vystup = "Je viacej lichých čísiel"
else
    vystup = "Počet sudých a lichých je rovnaký"
end