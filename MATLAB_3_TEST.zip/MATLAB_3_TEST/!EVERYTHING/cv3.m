clc,clear,close all;


r = 3;
circalc(r);