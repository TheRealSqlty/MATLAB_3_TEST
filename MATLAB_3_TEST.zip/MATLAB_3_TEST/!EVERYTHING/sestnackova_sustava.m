clc,clear,close all;

vstup = "303";
char_vstup = str2double(vstup);
zbytek = [];

while char_vstup > 0;
    zbytek(end+1) = mod(char_vstup,16);
    char_vstup = char_vstup/16;
    char_vstup = floor(char_vstup);
    disp (char_vstup)

end
flip_zbytek = fliplr(zbytek);
result = dec2hex(flip_zbytek)