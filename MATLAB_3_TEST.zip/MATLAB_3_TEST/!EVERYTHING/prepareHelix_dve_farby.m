% 1. Setup Environment
close all;  % Close all figures
clc;        % Clear the Command Window
clear;      % Clear the Workspace

% 2. Define Parameters
R = 1;          % Radius
H = 1;          % Pitch (z-distance for one 2*pi turn)
m = 3;          % Number of threads (parts)
numTurns = 2;   % Number of turns to show (to match the image)
numPoints = 100; % Number of points per thread

% 3. Call Function to Prepare Data
% This local function is defined at the end of this script
helixData = prepareHelixData(R, H, m, numTurns, numPoints);

% 4. Plot the Helix
figure;     % Create a new figure window
hold on;    % Hold the plot to draw all 'm' parts

fprintf('Plotting %d helix threads...\n', m);

for i = 1:m
    % Get the data for the i-th thread
    % This is where your error was:
    % helixData{i} was empty because the function was wrong.
    data = helixData{i}; 
    
    % Access rows 1, 2, and 3
    x = data(1, :); % X coordinates
    y = data(2, :); % Y coordinates
    z = data(3, :); % Z coordinates

    % Check if the thread index 'i' is odd or even
    if mod(i, 2) == 1
        % Odd parts (1, 3, 5, ...): Blue cross (x)
        plot3(x, y, z, 'bx', 'MarkerSize', 8, 'LineWidth', 1.5);
        fprintf('  Plotting thread %d as Blue Cross\n', i);
    else
        % Even parts (2, 4, 6, ...): Red dot (.)
        plot3(x, y, z, 'r.', 'MarkerSize', 14);
        fprintf('  Plotting thread %d as Red Dot\n', i);
    end
end

hold off;   % Release the plot

% 5. Format the Plot
axis equal; % Ensures circles look circular
grid on;    % Add a grid
box on;     % Enclose the plot in a box
xlabel('X');
ylabel('Y');
zlabel('Z');
title(['Helix with ', num2str(m), ' Threads']);
view(3);    % Set the default 3D view
rotate3d on; % Allow interactive rotation

fprintf('Plot complete.\n');
function data = prepareHelixData(R, H, m, numTurns, numPoints)
    % This function prepares 'm' sets of helix data (threads).
    
    % Create a base parameter 't' (angle)
    % It goes from 0 to (numTurns * 2*pi)
    t = linspace(0, numTurns * 2*pi, numPoints);
    
    % Calculate the z-coordinate factor.
    % z = b * t
    % H is the pitch (z-distance per 2*pi)
    b = H / (2*pi);
    
    % 'data' will be a cell array, where each cell holds one thread
    data = cell(m, 1);
    
    % Calculate the angle (phase) shift for each thread
    % A full circle (2*pi) is divided by 'm'
    phase_shift_per_thread = (2*pi) / m;
    
    for i = 1:m
        % Calculate the phase shift for this specific thread
        % (i-1) ensures the first thread (i=1) has 0 shift
        current_shift = (i - 1) * phase_shift_per_thread;
        
        % Apply the shift to 't' to get the (x, y) coordinates
        t_shifted = t + current_shift;
        
        % Calculate (x, y) coordinates
        x = R * cos(t_shifted);
        y = R * sin(t_shifted);
        
        % The z coordinate is the same for all threads, it just goes up.
        z = b * t;
        
        % Store this thread's [x; y; z] data in the cell array
        % This creates the 3xN matrix that the main script needs
        data{i} = [x; y; z];
    end
end