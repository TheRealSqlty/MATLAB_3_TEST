clc,clear,close all;

n = 100; %počet bodov
a = 15; %dlžka hrany

x = (a*rand(n,1))-a/2
y = (a*rand(n,1))-a/2

idx = x>0 & y>0
sx = [a/2 -a/2 -a/2 a/2 a/2]
sy = [a/2 a/2 -a/2 -a/2 a/2]

plot(sx,sy,"b")
hold on;
plot(x(idx),y(idx),"k*")
plot(x(~idx),y(~idx),"ro")
axis equal;
hold off;
