clc,clear,close all;
%% MATLAB Script: Weather Data Processing and Plotting

% --- Configuration ---
cityName = 'San Diego'; % << Change this to 'Miami' or another city if desired!

%% --- 1. Load Data from 'weather.csv' ---
try
    % Load the data into a table structure.
    T = readtable('weather.csv');
catch
    error('Could not find or load ''weather.csv''. Please make sure the file is in the current MATLAB path.');
end

%% --- 2. Choose City and Extract Data ---

% Find all rows that match the specified city name.
is_city = strcmp(T.City, cityName);
city_data = T(is_city, :);

if isempty(city_data)
    error('No data found for the city: %s. Check the spelling or if the city exists in the file.', cityName);
end

% Get temperature in Fahrenheit (temp_F) and Date (Y_data).
temp_F = city_data.Temperature;
Y_data = city_data.Date; 

%% --- 3. Convert Temperature from °F to °C ---
% Formula: T_C = (T_F - 32) * 5/9
X_data = (temp_F - 32) * (5/9); 

%% --- 4. Compute Average Temperature ---
avg_temp_C = mean(X_data);

%% --- 5. Prepare Plotting Data based on Average ---

% Create logical indices for points above and below the average line.
is_greater_than_avg = X_data > avg_temp_C;
is_lower_than_or_equal = X_data <= avg_temp_C;

% Separate the data for plotting:
temp_greater = X_data(is_greater_than_avg);
date_greater = Y_data(is_greater_than_avg);

temp_lower = X_data(is_lower_than_or_equal);
date_lower = Y_data(is_lower_than_or_equal);

%% --- 6. Create the Plot ---
figure; % Opens a new figure window

% Plot temperatures greater than average (red plus '+')
plot(date_greater, temp_greater, 'r+', 'MarkerSize', 8, 'DisplayName', 'Greater than Avg');
hold on; % Hold the plot to overlay the next two plots

% Plot temperatures lower than or equal to average (blue star '*')
plot(date_lower, temp_lower, 'b*', 'MarkerSize', 6, 'DisplayName', 'Lower than/Equal to Avg');

% Plot the average temperature to the graph as a horizontal green line ('g-')
% repmat creates a vector of the average temperature for the entire date range.
plot(Y_data, repmat(avg_temp_C, length(Y_data), 1), 'g-', 'LineWidth', 2, 'DisplayName', 'Average Temp');

hold off; % Release the plot hold

%% --- 7. Add Graph Labels and Title ---

% Create the title dynamically with the city name and the calculated average.
title_text = sprintf('Temperature in %s in 2016 (Avg: %.2f°C)', cityName, avg_temp_C);
title(title_text);

xlabel('Date');
ylabel('Temperature [°C]');

% Format the x-axis to show month abbreviations (e.g., Jan, Apr).
datetick('x', 'mmm', 'keeplimits'); 

% Add a legend to explain the markers and line
legend('Location', 'best');
grid on;