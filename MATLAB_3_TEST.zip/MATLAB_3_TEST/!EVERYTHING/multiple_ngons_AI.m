% Task 3: Concentric N-gons Plot

% 1. Preparation: Clean up the environment
clc;        % Clear the command window
clear;      % Clear all variables from the workspace
close all;  % Close all open figure windows

% 2. Define Parameters (Example: 5 concentric 8-gons)
m = 10;  % Number of concentric n-gons (m)
n = 8;  % Number of vertices for the n-gon (n)

% 3. Prepare the figure
figure;    % Create a new figure window
hold on;   % Allow multiple plots on the same axes
grid on;   % Add a grid
axis equal;% Ensure the scaling is equal on both axes
box on;    % Add a box around the plot

% Define the angles for the vertices (n+1 points to close the polygon)
theta = linspace(0, 2*pi, n + 1);

% 4. Loop to plot m concentric n-gons
for k = 1:m
    % The radius (R) of the circumscribed circle increases by 1 for each polygon
    R = k;

    % Calculate the (x,y) coordinates of the vertices
    x = R * cos(theta);
    y = R * sin(theta);

    % Determine the plotting style based on the loop index (k)
    if mod(k, 2) == 1  % Odd numbered polygon (1st, 3rd, 5th, ...)
        % Red solid line, thickness 2
        line_style = 'r-';
        line_thickness = 2;
    else % Even numbered polygon (2nd, 4th, ...)
        % Black dotted line, thickness 5
        line_style = 'k:';
        line_thickness = 5;
    end

    % A) Plot the N-gon line
    plot(x, y, line_style, 'LineWidth', line_thickness);

    % B) Plot the vertices as blue circular markers (only up to the N-th point)
    % The last point is a duplicate of the first to close the polygon, so we exclude it here.
    plot(x(1:n), y(1:n), 'bo', 'MarkerSize', 6, 'MarkerFaceColor', 'b');
end

% 5. Finalize the plot
hold off; % Release the figure
title(['Plot of ', num2str(m), ' Concentric ', num2str(n), '-gons']);
xlabel('X-axis');
ylabel('Y-axis');
% Adjust axis limits to ensure all polygons are visible (e.g., radius m+1)
axis([-(m+1) m+1 -(m+1) m+1]);