clc,clear,close all;

n = 5;

x = rand(1,5)
y = rand(1,5)

r = sqrt(x.^2 + y.^2);
R = max(r)

theta = linspace(0,2*pi,200)

xk = R *cos(theta)

yk = R*sin(theta) 


plot(x,y,'b.')
hold on;
axis equal;

plot(xk,yk,'r-')


hold off;

