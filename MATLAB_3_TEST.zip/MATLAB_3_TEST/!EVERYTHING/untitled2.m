clc,clear,close all

%parametre
R = 5;
N=10;

x0 =0;
y0 =0;
z0 =0;

%angle
fi = linspace(0,2*pi,4*N*10+1);

%circle
x = x0 + R*cos(fi);
y = y0 + R*sin(fi);
z = sin(linspace(0,2*pi*N,length(fi)));


for i = 1:length(z)

    if z(i)>0