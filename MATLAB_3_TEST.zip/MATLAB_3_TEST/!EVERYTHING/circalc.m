function circalc(r)
   if r>0
    c = 2*pi*r
    A = pi*r^2
   else
       disp("iba kladne čisla!!")
   end


end