%NA TOTO JE FUNKCIA TEXT_V_P
clc,clear,close all;
text1 = '0Y3X11X10Y1Y0X5Y5XRo';
[x1, y1] = Text_v_p(text1)
text2 = '2Y15X3X0Y0Y5X3Y7XG*';
[x2, y2] = Text_v_p(text2)
