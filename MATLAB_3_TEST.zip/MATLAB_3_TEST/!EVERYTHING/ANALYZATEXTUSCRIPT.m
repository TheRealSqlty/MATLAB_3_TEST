clc,clear,close all;

[P,E,N] = text_analysis('Včera som sa posral. Velmi to bolí.')