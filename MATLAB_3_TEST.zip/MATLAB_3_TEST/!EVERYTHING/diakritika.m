function [txt_new,num] = diakritika (text)

num = 0;
txt_new = [];
txt_char= char(text);

for i = 1:length(txt_char)
    if txt_char(i)<127
        txt_new(end+1)=txt_char(i);
    else
        num = num+1;
    end
end
txt_new = char(txt_new);
txt_new = string(txt_new);
disp("Novy text: " + txt_new)
disp("pocet odstranenych znakov : " + num)

end



