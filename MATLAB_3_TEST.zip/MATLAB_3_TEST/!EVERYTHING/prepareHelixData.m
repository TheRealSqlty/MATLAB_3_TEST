function data = prepareHelixData(R, H, m, numTurns, numPoints)
    % This function prepares 'm' sets of helix data (threads).
    
    % Create a base parameter 't' (angle)
    % It goes from 0 to (numTurns * 2*pi)
    t = linspace(0, numTurns * 2*pi, numPoints);
    
    % Calculate the z-coordinate factor.
    % z = b * t
    % H is the pitch (z-distance per 2*pi)
    b = H / (2*pi);
    
    % 'data' will be a cell array, where each cell holds one thread
    data = cell(m, 1);
    
    % Calculate the angle (phase) shift for each thread
    % A full circle (2*pi) is divided by 'm'
    phase_shift_per_thread = (2*pi) / m;
    
    for i = 1:m
        % Calculate the phase shift for this specific thread
        % (i-1) ensures the first thread (i=1) has 0 shift
        current_shift = (i - 1) * phase_shift_per_thread;
        
        % Apply the shift to 't' to get the (x, y) coordinates
        t_shifted = t + current_shift;
        
        % Calculate (x, y) coordinates
        x = R * cos(t_shifted);
        y = R * sin(t_shifted);
        
        % The z coordinate is the same for all threads, it just goes up.
        z = b * t;
        
        % Store this thread's [x; y; z] data in the cell array
        % This creates the 3xN matrix that the main script needs
        data{i} = [x; y; z];
    end
end