function vianocna_hviezda(n,r)
hold on;
axis equal;


krok = n/2-0.5;
theta = linspace(0 , 2*pi*krok , n+1)

x = r *cos (theta);
y = r * sin (theta);
plot (x,y)
end
