% Script test_task_2.m: Calls the switch_case function.

% Preparation
clc;        % Clear the command window
clear;      % Clear all variables from the workspace

% Example 1: 'Toto je druHY zaPOctovy test'
text1 = 'Toto je druHY zaPOctovy test';
new_text1 = switch_case(text1);

disp(['Input:  ''', text1, '''']);
disp(['Output: ''', new_text1, '''']);
% Expected Output: 'tOTO JE DRUhY ZApoCTOVY TEST'

disp('------------------------');

% Example 2: 'Mam rad Ovoce a Zeleninu'
text2 = 'Mam rad Ovoce a Zeleninu';
new_text2 = switch_case(text2);

disp(['Input:  ''', text2, '''']);
disp(['Output: ''', new_text2, '''']);
% Expected Output: 'mAM RAD oVOCE A zELENINU'