function [vysledok] = fdelitelnetridevat(cislo)

text = num2str(cislo);
cifry = text - '0';
sucet = sum(cifry);


delitelne3 = (sucet/3) == floor(sucet/3);
delitelne9 = (sucet/9) == floor(sucet/9);

vysledok = [delitelne3, delitelne9];

