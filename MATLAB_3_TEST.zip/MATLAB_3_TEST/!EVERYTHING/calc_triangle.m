function [validity,area,circumference] = calc_triangle(a,b,c)
%calc_triangle Vypočítanie validity, area a circumference
%   Detailed explanation goes here
arguments (Input)
    a
    b
    c
end

arguments (Output)
    validity
    area
    circumference
end

if a+b>c && a+c>b && b+c>a
    validity = true
else 
    validity = false
end
area = sin(acos((a*2+b^2-c^2)/2*a*b))*a*b/2;
circumference = a+b+c;
end