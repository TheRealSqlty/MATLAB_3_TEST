clc,clear,close all;

c = 'Hello world'
test = "Hello world"

sifra 'mam rad svojich kamaratov' 5