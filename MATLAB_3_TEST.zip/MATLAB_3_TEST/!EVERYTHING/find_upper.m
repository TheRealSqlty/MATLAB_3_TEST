function output_text = find_upper(input_text)
% FIND_UPPER Inserts '|' characters around every uppercase letter in the input text.
%   Inputs:
%     input_text - A string of text.
%   Outputs:
%     output_text - The string with uppercase letters bracketed by '|'.


    char_array = char(input_text);                           % Convert the input string to a character array for element-wise processing
    

    new_parts = {};                                            % Initialize an empty cell array to store the processed parts
    

    for i = 1:length(char_array)                               % Loop through each character in the input array
        current_char = char_array(i);
        

        if isstrprop(current_char, 'upper')                        % Check if the current character is an uppercase letter

            new_char = ['|', current_char, '|'];                  % If it's uppercase, bracket it with '|' and store
        else
  
            new_char = current_char;                                   % If it's not uppercase (or is a space/number), store it as is
        end
        

        new_parts{end+1} = new_char;                               % Add the processed character/string to the cell array
    end
    

    output_text = [new_parts{:}];                                    % Join all parts of the cell array into a single string for the output
end