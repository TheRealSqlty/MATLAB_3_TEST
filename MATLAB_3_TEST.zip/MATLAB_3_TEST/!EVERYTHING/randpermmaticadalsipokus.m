clc,clear,close all;


opakovanie = 0;
matica = zeros(20,5)

for i = (1:20)
    matica(i,:) =randperm(5)
end

for i = (1:20)
    for j = 1:5
        if matica(i,j) == j
        opakovanie = opakovanie+1;
        end
    end
end
disp("pocet opakovani:" + opakovanie)