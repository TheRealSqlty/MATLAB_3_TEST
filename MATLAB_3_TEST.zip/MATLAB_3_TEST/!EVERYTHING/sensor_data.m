%% Task 1: Sensor Data Analysis

% 1. Preparation: Clean up the environment
close all;      % Close all open figure windows
clc;            % Clear the command window
clear;          % Clear all variables from the workspace

%% 2. Load data from the file
% The file contains two columns separated by ', ' and includes units ('s', 'N').
% We use textscan to handle the complex format robustly.
fileID = fopen('sensor.txt', 'r');

% Format specification: '%f' (Time float), '%s' (unit 's,'), '%f' (Force float), '%s' (unit 'N')
data = textscan(fileID, '%f %s %f %s', 'Delimiter', ','); 
fclose(fileID);

% Extract the time and force data
Time = data{1};
Force = data{3};

%% 3. Identify Peaks (Maxima) in the Force Signal
% A peak (vrchol) occurs when the signal changes from increasing (growth) to decreasing (decline).

% Calculate the difference (slope/gradient) between consecutive force measurements
% diff(Force) gives a vector of length N-1.
Diff_Force = diff(Force);

% Pre-allocate an array for the peak markers with NaN (to hide markers by default)
Peak_Markers = NaN(size(Force));

% The peak comparison starts from the second point (index 2) and ends at the second-to-last point (N-1).
% We exclude the first and last points, as they don't have a change on both sides.
for i = 2:(length(Force) - 1)
    % Check for peak condition:
    % 1. The previous step was increasing (positive difference)
    % 2. The current step is decreasing (negative difference)
    if (Diff_Force(i-1) > 0) && (Diff_Force(i) < 0)
        % This point (Force(i)) is a local maximum (a peak)
        Peak_Markers(i) = Force(i);
    end
end

%% 4. Plot the data
figure;  % Create a new figure
hold on; % Allow multiple plots on the same axes

% Plot the raw sensor data (blue line)
plot(Time, Force, 'b-', 'LineWidth', 1, 'DisplayName', 'Sensor data');

% Plot the identified peaks (Red circular markers)
plot(Time, Peak_Markers, 'ro', 'MarkerSize', 6, 'MarkerFaceColor', 'r', 'DisplayName', 'Peaks');

hold off; % Release the plot
axis tight; % Fit the axes to the data

%% 5. Add labels and formatting
xlabel('Time [s]');            % X-axis label
ylabel('Force [N]');           % Y-axis label
title('Měření síly silovým senzorem'); % Title
legend('Location', 'southwest'); % Add legend
grid on;                       % Turn on the grid