vstup = "jablko";
vstup = char(vstup);
vstup = fliplr(vstup);


for i = 1:length(vstup)
    if vstup(i) == 'a'
    vstup(i) = '0'
    elseif vstup(i) == 'e' 
        vstup(i) = '1'
    elseif vstup (i) == 'i'  
        vstup(i) = '2'
    elseif vstup (i) == 'o' 
        vstup(i) = '3'
    elseif vstup (i) == 'u' 
        vstup(i) = '4'
    elseif vstup (i) == 'y' 
        vstup(i) = '5'
    end
end
disp(vstup)

