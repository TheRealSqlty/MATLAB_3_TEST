clc,clear,close all;

subplot(2,1,1)

x = randi(6,1000,1);
nbins = 6;
histogram(x,nbins)

subplot(2,1,2)
x2 = randi(6,1000,1);
x3 = randi(6,1000,1);
x4 = x2+x3;
histogram(x4,11)
