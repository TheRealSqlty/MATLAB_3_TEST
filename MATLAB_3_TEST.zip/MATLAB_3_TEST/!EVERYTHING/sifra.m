function [output] = sifra(char_array,k)
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here
arguments (Input)
    char_array 
    k
end

arguments (Output)
    output
end
k   = mod(k,26);
ascii_values = double(char_array);
a_ascii = double('a');
z_ascii = double('z');
is_letter = (ascii_values >= a_ascii) & (ascii_values <= z_ascii);
letter_ascii = ascii_values(is_letter);
normalized_values = letter_ascii - a_ascii;
shifted_normalized = mod(normalized_values + k, 26);
shifted_letter_ascii = shifted_normalized + a_ascii;
ascii_values(is_letter) = shifted_letter_ascii;
output = char(ascii_values)
end