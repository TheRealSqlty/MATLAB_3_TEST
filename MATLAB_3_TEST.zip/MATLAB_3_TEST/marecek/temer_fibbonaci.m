clc,clear,close all

theta = linspace(0,pi,400);
iterace = 30;
polomer = 5;
offset = 0;
stred = 0;

for i = 1:iterace
    if mod(i,2)==0
        x = polomer * cos(theta) + offset;
        y = polomer * sin(theta)*(-1);
        offset = stred + polomer/2;
    else
        x = polomer * cos(theta) + offset;
        y = polomer * sin(theta);
        offset = stred-polomer/2;
    end
    plot(x,y)
    hold on;
    axis equal;
    stred = offset;
    polomer = polomer/2;
end