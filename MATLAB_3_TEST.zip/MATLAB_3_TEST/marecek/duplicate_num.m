clc,clear
numbers = [4,7,3,5,6,8,6,5,8,7];

result = find_duplicate(numbers);
disp(result)

function nonduplicate = find_duplicate(numbers)
    nonduplicate = [];
    for i = 1:length(numbers)
        num = numbers(i);
        duplicate = false;
        for j = 1:length(nonduplicate)
            if nonduplicate(j) == num
                duplicate = true;
                break;
            end
        end
        if ~duplicate
            nonduplicate(end + 1) = num;
        end
    end
end