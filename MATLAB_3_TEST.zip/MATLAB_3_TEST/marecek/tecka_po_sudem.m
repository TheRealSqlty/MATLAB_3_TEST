clc,clear

text = "ABCDEF";
char_text = char(text);
new_txt = [];

for i = 1:length(char_text)
    position = char_text(i) + 'a' + 1;
    if mod(position,2) == 0
        new_txt(end+1) = lower(char_text(i));
        new_txt(end+1) = '.';
    else
        new_txt(end+1) = char_text(i);
    end
end

text = string(char(new_txt));
disp(text)