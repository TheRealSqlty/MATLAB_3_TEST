clc,clear

text1 = "test pro";
text2 = "Konecny test pro 1 PA";

if strlength(text1) > strlength(text2)
    obsahuje = contains(text1,text2);
else
    obsahuje = contains(text2,text1);
end

disp(obsahuje)