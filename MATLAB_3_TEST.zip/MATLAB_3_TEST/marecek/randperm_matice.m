clc, clear

matice = zeros(20,5);
counter = 0;

for i = 1:size(matice,1)
    rand_order = randperm(5);
    matice(i,:) = rand_order;

    % Check if any element matches its column number
    for c = 1:5
        if matice(i,c) == c
            counter = counter + 1;
        end
    end
end

disp(matice)
disp(counter)