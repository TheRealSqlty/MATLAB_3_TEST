clc, clear

vstup = '546678';
vystup = 0;

for i = 1:length(vstup)
    cislo = vstup(i);
    if cislo > 47 && cislo < 58
        vystup = vystup * 10 + (vstup(i) - 48);
    else
        vystup = [];
        break
    end
end