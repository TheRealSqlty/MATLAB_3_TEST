clc,clear

vstup = "Test z 1PA je tu";
result = slozita_funkce(vstup);
disp(result)

function vystup = slozita_funkce(vstup)
    vstup = upper(vstup);
    vstup = char(vstup);

    vstup(vstup <= 65 | vstup >= 90) = [];
    vstup = sort(vstup);
    b=vstup(1);
    for i = 2:length(vstup)
        if vstup(i) ~=b(end)
            b(end+1) = vstup(i);
        end
    end
    vystup = b;
end