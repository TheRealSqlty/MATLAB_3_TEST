clc,clear

my_num = '56894';
result = [];

for i = 1:length(my_num)
    if ischar(my_num) == 1 && my_num(i)>=48 && my_num(i)<= 57
        result(end+1) = (my_num(i)- 48);
    else
        result=[];
    end
end
disp(result)
disp("Neni char")