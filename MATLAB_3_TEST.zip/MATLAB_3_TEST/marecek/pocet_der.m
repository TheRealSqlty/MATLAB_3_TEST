clc,clear

cislo = 44418;
cislo = num2str(cislo);
diry = 0;

for i = 1:length(cislo)
    if cislo(i) == '4' || cislo(i) == '6' || cislo(i) == '0' || cislo(i) == '9'
        diry = diry + 1;
    elseif cislo(i) == '8'
        diry = diry + 2;
    end
end
