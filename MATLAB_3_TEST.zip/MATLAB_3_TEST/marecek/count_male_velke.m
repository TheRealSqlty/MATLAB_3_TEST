clc,clear
text = 'eeeEbbbb';
hledane = 'e';
[male, velke] = n_male_velke(text,hledane);

fprintf("male: %d, velke: %d\n", male, velke);

function [counter_male, counter_velke] = n_male_velke(text,hledane)
    counter_male = 0;
    counter_velke = 0;
    
    for i = 1:length(text)
        if text(i) == hledane
            counter_male = counter_male + 1;
        elseif text(i) == hledane - 32
            counter_velke = counter_velke + 1;
        end
    end
end
