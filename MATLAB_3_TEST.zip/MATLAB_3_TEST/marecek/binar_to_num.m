clc,clear

text = "101110101";
text_char = char(text);
suma_celkova = 0;
delka_cisla = length(text_char);

for i = 1:delka_cisla
    if text_char(delka_cisla-i+1) == "1"
        suma_celkova = suma_celkova + 2^(i-1);
    end
end
disp(suma_celkova)