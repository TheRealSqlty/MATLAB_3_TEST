clc; clear;

r = 3;
R = 5;

theta = linspace(0,2*pi,400);

x1 = r * cos(theta);
y1 = r * sin(theta);

x2 = R * cos(theta);
y2 = R * sin(theta);

N = 200;
x_body = rand(1,N)*10 - 5;
y_body = rand(1,N)*10 - 5;

hold on;
axis equal;

plot(x1, y1, 'r--', 'LineWidth', 2);
plot(x2, y2, 'b-', 'LineWidth', 2);

dist = sqrt(x_body.^2 + y_body.^2);

idx = dist >= r & dist <= R;
plot(x_body(idx), y_body(idx), 'b.', 'MarkerSize', 10);