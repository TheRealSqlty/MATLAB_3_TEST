clc,clear

vstup = 'neeeee kurvaaaa';

for i =2:length(vstup)
    if vstup(i-1) == ' '
        vstup(i) = upper(vstup(i));
        vstup(i-1) = '';
    elseif vstup(end) == ' '
        break
    end
end
disp(vstup)