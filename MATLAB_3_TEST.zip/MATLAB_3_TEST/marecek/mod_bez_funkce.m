clc,clear

num = 36;

while true
    new_num = num / 2;

    if new_num ~= floor(new_num)
        disp("Num is not divisible by 2")
        break
    end

    num = new_num;

    if num == 1
        disp("Num is divisible by 2")
        break
    end
end
