clc,clear

text = "abcdef";
char_txt = char(text);

for i = 1:length(char_txt)
    position = char_txt(i)- 'a' + 1;
    if mod(position,2) == 1
        char_txt(i) = char_txt(i)-32;
    end
end
text = string(char(char_txt));
disp(text)