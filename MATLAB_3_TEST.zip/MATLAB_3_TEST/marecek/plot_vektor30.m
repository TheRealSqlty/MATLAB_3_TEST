clc; clear;

y_vektor = rand(1,30);
x_vektor = 1:30;
prumer = mean(y_vektor);

hold on;
for i = 1:30
    if i == 1
        plot(i, y_vektor(i), 'bo', 'MarkerSize', 5, 'MarkerFaceColor', 'b');
    else
        if y_vektor(i-1) <= y_vektor(i)
            plot([x_vektor(i-1) x_vektor(i)], [y_vektor(i-1) y_vektor(i)], 'b-');
            plot(i, y_vektor(i), 'bo', 'MarkerSize', 5, 'MarkerFaceColor', 'b');
        else
            plot([x_vektor(i-1) x_vektor(i)], [y_vektor(i-1) y_vektor(i)], 'b-');
            plot(i, y_vektor(i), 'ro', 'MarkerSize', 5, 'MarkerFaceColor', 'r');
        end
    end
end

yline(prumer, 'r--', 'LineWidth', 1.2);

xlabel('Index');
ylabel('Random Value');
title('Random values with color depending on trend');
hold off;



