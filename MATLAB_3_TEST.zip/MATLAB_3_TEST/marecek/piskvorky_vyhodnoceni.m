clc; clear

piskvorky = ['X','O','O','X','O';
             'X','O','O','O','O';
             'X','O','X','X','O';
             'X','O','O','X','X';
             'X','O','O','X','O'];

vysledek = [];

% Check rows
for i = 1:size(piskvorky,1)
    if all(piskvorky(i,:) == 'X')
        vysledek = 'krizky';
    elseif all(piskvorky(i,:) == 'O')
        vysledek = 'krouzky';
    end
end

% Check columns
for i = 1:size(piskvorky,2)
    if all(piskvorky(:,i) == 'X')
        vysledek = 'krizky';
    elseif all(piskvorky(:,i) == 'O')
        vysledek = 'krouzky';
    end
end

disp(vysledek)
