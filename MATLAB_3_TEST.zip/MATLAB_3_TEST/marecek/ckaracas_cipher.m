clc, clear

vstup = "jablko";
vstup = fliplr(vstup);

for i = 1:length(char(vstup))
    pismeno = vstup(i);

    if pismeno == 'a'
        vstup(i) = '0';
    elseif pismeno == 'e'
        vstup(i) = '1';
    elseif pismeno == 'i'
        vstup(i) = '2';
    elseif pismeno == 'o'
        vstup(i) = '3';
    elseif pismeno == 'u'
        vstup(i) = '4';
    end
end

disp(vstup)
% if we do pismeno = then we only change the the wariable pismeno not the
% actual char in vstup
