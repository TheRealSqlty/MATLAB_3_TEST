clc,clear,close all

xbody = rand(1,100);
ybody = rand(1,100);

xmin = min(xbody);
xmax = max(xbody);
ymin = min(ybody);
ymax = max(ybody);

recx = [xmin xmax xmax xmin xmin];
recy = [ymin ymin ymax ymax ymin];

hold on
plot(xbody,ybody,'b+')
plot(recx,recy,'b--')