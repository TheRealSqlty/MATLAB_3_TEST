clc,clear

vstup = 2435;
liche = 0;
sude = 0;

vstup = num2str(vstup);
%vstup = char(vstup); prej to hází rovnou do charu
for i = 1:length(vstup)
    if mod(vstup(i),2)==1
        liche = liche+1;
    else
        sude = sude+1;
    end
end
if liche > sude
    disp(liche)
    disp("Liche")
elseif liche == sude
    disp(liche)
    disp(sude)
    disp("Stejne")
else
    disp(sude)
    disp("Sude")
end