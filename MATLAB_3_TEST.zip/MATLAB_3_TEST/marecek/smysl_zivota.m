clc,clear

cislo = '4266642';
counter42 = 0;
counter666 = 0;


if cislo(end-1) == '4' && cislo(end) == '2'
    counter42 = counter42 + 1;
end
for i = 3:length(cislo)
    first_digit = cislo(i-2);
    second_digit = cislo(i-1);
    third_digit = cislo(i);
    if second_digit == '2' && first_digit == '4'
        counter42 = counter42 + 1;
    elseif first_digit == '6' && second_digit == '6' && third_digit == '6'
        counter666 = counter666 + 1;
    end
end
disp(counter666)
disp(counter42)