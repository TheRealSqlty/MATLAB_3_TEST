clc,clear

any_vektor([1 1 1 1],2,2)

function vystup = any_vektor(vektor,row,column)
    vektor_size = row * column;
    vektor_length = length(vektor);
    vystup = zeros(row,column);

    if vektor_length == vektor_size
        for i = 1:row
            row_start = (i-1)*column + 1;
            vystup(i,:) = vektor(row_start : row_start + column - 1);
        end
    else
        vystup = [];
        disp("Incorrect vector input")
    end
end