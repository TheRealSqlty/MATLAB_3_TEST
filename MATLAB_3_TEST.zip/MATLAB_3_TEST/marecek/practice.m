clc, clear

text = 'Ahoj das to';
text = nejaka_fce(text)

function text = nejaka_fce(text)
    for i = 1:length(text)
        if mod(i,2) == 0
            text(i) = upper(text(i));
        else
            text(i) = lower(text(i));
        end
    end
end



str1 = 'Nejaka kokotina';
str2 = 'kokotina';

spolecne = '';

for i = 1:length(str1)
    for j = 1:length(str2)
        if str1(i) == str2(j) && ~ismember(str1(i), spolecne)
       %if str1(i) == str2(j) && ~any(str1(i) == spolecne)
            spolecne = [spolecne str1(i)];
        end
    end
end

disp(spolecne)