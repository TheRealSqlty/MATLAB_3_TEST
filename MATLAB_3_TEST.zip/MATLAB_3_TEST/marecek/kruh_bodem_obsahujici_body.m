clc,clear,close all

x = rand(1,4);
y = rand(1,4);

plot(x,y,'g.',MarkerSize=20)

R = 0;
for i = 1:length(x)
    r = sqrt(x(i)^2 + y(i)^2);
    if r>R
        R = r;
    end
end

theta = linspace(0,2*pi,200);

kx = R * cos(theta);
ky = R * sin(theta);

hold on
axis equal
plot(kx,ky,'r')
