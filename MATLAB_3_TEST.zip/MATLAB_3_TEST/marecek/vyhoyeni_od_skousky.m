clc,clear

str = 'Ahoj  jak  se  mas?';
old = '  ';
new = ' ';
new_str = strrep(str,old,new);