clc; clear;

N = 1000;
x = rand(N,1);
y = rand(N,1);

figure; hold on;

xmax = max(x);
ymax = max(y);

% Square coordinates
xsq = [1/3*xmax 2/3*xmax 2/3*xmax 1/3*xmax 1/3*xmax];
ysq = [1/3*ymax  1/3*ymax  2/3*ymax 2/3*ymax 1/3*ymax];

% Plot square
plot(xsq, ysq, 'k-')

axis equal

% Highlight points inside
for i = 1:N
    if x(i) > xsq(1) && x(i) < xsq(2) && y(i) > ysq(1) && y(i) < ysq(3)
        plot(x(i), y(i), 'r+', 'MarkerSize', 10, 'LineWidth', 2);
    else
        plot(x(i), y(i), 'bo') % blue circles for all points
    end
end
