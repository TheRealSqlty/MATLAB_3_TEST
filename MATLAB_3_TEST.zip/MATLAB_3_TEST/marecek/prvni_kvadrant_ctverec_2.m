clc,clear, close all
hold on
axis equal


theta = linspace(pi/4,2*pi+pi/4,5);
r = sqrt(5^2 + 5^2);
sqx = r * cos(theta);
sqy = r * sin(theta);
plot(sqx,sqy,'b-','LineWidth',5)
xlim([-5,5])
ylim([-5,5])

n = 500;
xrand = rand(n)*10-5;
yrand = rand(n)*10-5;


for i = 1:length(yrand)
    if xrand(i) >= 0 && yrand(i) >=0
        plot(xrand(i),yrand(i),'k+')
    else
        plot(xrand(i),yrand(i),'r*')
    end
end