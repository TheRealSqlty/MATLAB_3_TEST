clc,clear,close all

n = 8;
r = 5;

theta = linspace(0,2*pi,n+1);

x = r * cos(theta);
y = r * sin(theta);

plot(x,y,'b-')

hold on
axis equal

for i = 1:n
    x1 = x(i) + cos(theta);
    y1 = y(i) + sin(theta);

    plot(x1,y1,'r*')
end