clc,clear
text = "část hřídele";
[a,b] = diakritika(text)

function [txt_new, num] = diakritika(text)
    num = 0;
    txt_char = char(text);
    txt_new = [];
    
    for i = 1:length(txt_char)
        if (txt_char(i)< 127)
            txt_new(end+1) = txt_char(i);
        else
            num = num + 1;
        end
    end
    txt_new = string(char(txt_new));
end
