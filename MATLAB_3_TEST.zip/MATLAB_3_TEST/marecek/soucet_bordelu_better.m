clc,clear

%regexp

vstup = "1 2_3-5, 5 und 7";
char_vstup = char(vstup);

A = [];
id = 1;
vysledek = 0;

for i = 1:length(char_vstup)
    if char_vstup(i) > 47 && char_vstup(i) < 58
        A = [A char_vstup(i)];
    else
        if ~isempty(A)
            vysledek = vysledek + str2double(A);
            A = [];
        end
    end
end
if ~isempty(A)
    vysledek = vysledek + str2double(A);
end

disp(vysledek)