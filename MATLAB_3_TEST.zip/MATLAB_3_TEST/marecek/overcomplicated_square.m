clc,clear,close all

x0 = 0;
y0 = 0;
n = 4;
angle = 0;
a = 4;

hold on
axis equal
xlim([-1,5])
ylim([-1,5])

for i = 1:n
    x1 = x0 + a * cosd(angle);
    y1 = y0 + a * sind(angle);
    plot([x0,x1],[y0,y1],'b-','LineWidth',5)
    x0 = x1;
    y0 = y1;
    angle = angle + 90;
end