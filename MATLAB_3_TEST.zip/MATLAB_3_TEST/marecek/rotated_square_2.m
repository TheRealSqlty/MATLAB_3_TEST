clc; clear; close all;
hold on; axis equal;

N = 1000;
x = rand(N,1)*4 - 2;
y = rand(N,1)*4 - 2;

r = sqrt(2^2 + 2^2);
theta = linspace(0,2*pi,5);

xs = r*cos(theta);
ys = r*sin(theta);

plot(xs, ys, 'k-', 'LineWidth', 3);

phi = -45;

R = [cosd(phi) -sind(phi);
     sind(phi)  cosd(phi)];

rot = R * [x'; y']; % the ´ rotates the coordinate system not the same as x used for the points

xr = rot(1,:)';
yr = rot(2,:)';
% by doing this we rotate the entire coordinate system so its as if we had
% a normaly rotaed square (když budha nemůže k hoře přines horu k budhovi aproach)

inside = (abs(xr) <= 2) & (abs(yr) <= 2); %two in one no x>2 x<2

plot(x(inside), y(inside), 'r*', 'MarkerSize', 10, 'LineWidth', 1.5);
plot(x(~inside), y(~inside), 'b+');
