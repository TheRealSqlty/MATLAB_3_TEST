clc,clear

text = 'svbksyfgskf';

vety = 0;
slova = 1;
pismena = 0;

for i = 1:length(text)
    % pokud je na zacatku tecka nebo mezernik

    if text(i) == ' '
        slova = slova + 1;
    elseif text(i) == '.'
        vety = vety + 1;
    elseif text(i) ~= ' '
        slova = slova + 1;
    end
end